package ch.uzh.ifi.hase.soprafs22.constant;

public enum ReadyStatus {
    READY, UNREADY;
}
