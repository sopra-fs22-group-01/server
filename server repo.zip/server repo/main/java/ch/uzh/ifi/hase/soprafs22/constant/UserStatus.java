package ch.uzh.ifi.hase.soprafs22.constant;

//some comment to test git
public enum UserStatus {
  //OFFLINE = 0 in database, ONLINE = 1 in database
  OFFLINE, ONLINE;
}
