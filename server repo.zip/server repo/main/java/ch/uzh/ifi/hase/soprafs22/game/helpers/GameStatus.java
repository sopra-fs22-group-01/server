package ch.uzh.ifi.hase.soprafs22.game.helpers;

public enum GameStatus {
    //just some suggestions for different game status
    Ongoing, Lobby, NotStarted, Empty
}
