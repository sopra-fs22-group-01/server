package ch.uzh.ifi.hase.soprafs22.game.helpers;

public enum LobbyStatus {
    Waiting, All_Ready
}
