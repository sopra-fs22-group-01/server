package ch.uzh.ifi.hase.soprafs22.game.helpers;

public class Timer {

    private int time = 30;

    public void setTimer(){}

    public void startTimer(){
    }
    public int getTimeLeft(){
        return time;
    }


}
